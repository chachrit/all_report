<?php
// upload_csv_to_sqlserver.php
session_start();

// การตั้งค่าการเชื่อมต่อ SQL Server
$serverName = "localhost"; // หรือ IP ของ SQL Server
$connectionInfo = array(
    "Database" => "your_database_name",
    "UID" => "your_username",
    "PWD" => "your_password",
    "CharacterSet" => "UTF-8"
);

// เชื่อมต่อ SQL Server
$conn = sqlsrv_connect($serverName, $connectionInfo);
if (!$conn) {
    die("Connection failed: " . print_r(sqlsrv_errors(), true));
}

$message = '';
$messageType = '';

// ฟังก์ชันแปลงวันที่จาก CSV
function convertDate($dateStr) {
    if (empty($dateStr)) return null;
    try {
        $date = DateTime::createFromFormat('m/d/Y', $dateStr);
        return $date ? $date->format('Y-m-d') : null;
    } catch (Exception $e) {
        return null;
    }
}

// ฟังก์ชันแปลง datetime จาก CSV
function convertDateTime($dateTimeStr) {
    if (empty($dateTimeStr)) return null;
    try {
        $date = DateTime::createFromFormat('m/d/y g:i A', $dateTimeStr);
        if (!$date) {
            $date = DateTime::createFromFormat('m/d/Y g:i A', $dateTimeStr);
        }
        return $date ? $date->format('Y-m-d H:i:s') : null;
    } catch (Exception $e) {
        return null;
    }
}

// ฟังก์ชันแปลงตัวเลข
function convertNumber($numStr) {
    if (empty($numStr) || $numStr === 'NULL') return 0;
    return floatval(str_replace(',', '', $numStr));
}

// ประมวลผลเมื่อมีการอัปโหลดไฟล์
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    $file = $_FILES['csv_file'];
    $fileType = $_POST['file_type'] ?? 'jst';
    
    if ($file['error'] === UPLOAD_ERR_OK) {
        $tmpName = $file['tmp_name'];
        $handle = fopen($tmpName, 'r');
        
        if ($handle !== false) {
            // ข้าม header row
            $header = fgetcsv($handle);
            
            $successCount = 0;
            $errorCount = 0;
            $errors = [];
            
            // เริ่ม transaction
            sqlsrv_begin_transaction($conn);
            
            try {
                if ($fileType === 'jst') {
                    // อัปโหลด JST_sale_detail
                    $sql = "INSERT INTO jst_sale_detail 
                            (orderId, orderNumber, platformOrderId, sale_date, order_datetime, 
                             status, statusDisplay, platform, subtotal, net_sales, 
                             shop_discount, total_discount, freight, payment_channel, buyer_name)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    
                    while (($data = fgetcsv($handle)) !== false) {
                        if (count($data) >= 15) {
                            $params = array(
                                $data[0],                                    // orderId
                                $data[1],                                    // orderNumber
                                $data[2],                                    // platformOrderId
                                convertDate($data[3]),                       // sale_date
                                convertDateTime($data[4]),                   // order_datetime
                                $data[5],                                    // status
                                $data[6] ?? null,                            // statusDisplay
                                $data[7],                                    // platform
                                convertNumber($data[8]),                     // subtotal
                                convertNumber($data[9]),                     // net_sales
                                convertNumber($data[10]),                    // shop_discount
                                convertNumber($data[11]),                    // total_discount
                                convertNumber($data[12]),                    // freight
                                $data[13],                                   // payment_channel
                                $data[14] ?? null                            // buyer_name
                            );
                            
                            $stmt = sqlsrv_query($conn, $sql, $params);
                            if ($stmt === false) {
                                $errorCount++;
                                $errors[] = "Row " . ($successCount + $errorCount + 1) . ": " . 
                                           print_r(sqlsrv_errors(), true);
                            } else {
                                $successCount++;
                            }
                        }
                    }
                } else {
                    // อัปโหลด Pos-sale-detail (ปรับตามโครงสร้างจริง)
                    $sql = "INSERT INTO pos_sale_detail (column1, column2) VALUES (?, ?)";
                    
                    while (($data = fgetcsv($handle)) !== false) {
                        // เพิ่มโค้ดสำหรับ Pos-sale-detail ตามโครงสร้างไฟล์จริง
                        $successCount++;
                    }
                }
                
                // Commit transaction
                if ($errorCount === 0) {
                    sqlsrv_commit($conn);
                    $message = "อัปโหลดสำเร็จ! จำนวน {$successCount} รายการ";
                    $messageType = 'success';
                } else {
                    sqlsrv_rollback($conn);
                    $message = "เกิดข้อผิดพลาด! ยกเลิกการอัปโหลดทั้งหมด";
                    $messageType = 'error';
                }
                
            } catch (Exception $e) {
                sqlsrv_rollback($conn);
                $message = "เกิดข้อผิดพลาด: " . $e->getMessage();
                $messageType = 'error';
            }
            
            fclose($handle);
        }
    } else {
        $message = "เกิดข้อผิดพลาดในการอัปโหลดไฟล์";
        $messageType = 'error';
    }
}

// ดึงข้อมูลล่าสุดเพื่อแสดง
$recentData = array();
$query = "SELECT TOP 10 * FROM jst_sale_detail ORDER BY created_at DESC";
$stmt = sqlsrv_query($conn, $query);
if ($stmt) {
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $recentData[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>อัปโหลด CSV ไปยัง SQL Server</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        h1 {
            color: #333;
            border-bottom: 2px solid #007bff;
            padding-bottom: 10px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        input[type="file"], select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        button {
            background: #007bff;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s;
        }
        button:hover {
            background: #0056b3;
        }
        .alert {
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background: #007bff;
            color: white;
        }
        tr:hover {
            background: #f5f5f5;
        }
        .info-box {
            background: #e7f3ff;
            border-left: 4px solid #007bff;
            padding: 15px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📊 อัปโหลดไฟล์ CSV ไปยัง SQL Server</h1>
        
        <?php if ($message): ?>
            <div class="alert alert-<?php echo $messageType; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        
        <div class="info-box">
            <strong>หมายเหตุ:</strong> ไฟล์ CSV ต้องมีรูปแบบตามตัวอย่างใน JST_sale_detail.csv
        </div>
        
        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="file_type">ประเภทไฟล์:</label>
                <select name="file_type" id="file_type" required>
                    <option value="jst">JST Sale Detail</option>
                    <option value="pos">POS Sale Detail</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="csv_file">เลือกไฟล์ CSV:</label>
                <input type="file" name="csv_file" id="csv_file" accept=".csv" required>
            </div>
            
            <button type="submit">🚀 อัปโหลดข้อมูล</button>
        </form>
    </div>
    
    <?php if (!empty($recentData)): ?>
    <div class="container">
        <h2>📋 ข้อมูลล่าสุด (10 รายการ)</h2>
        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Order Number</th>
                    <th>Platform</th>
                    <th>Sale Date</th>
                    <th>Net Sales</th>
                    <th>Payment Channel</th>
                    <th>Buyer Name</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recentData as $row): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['orderId']); ?></td>
                    <td><?php echo htmlspecialchars($row['orderNumber']); ?></td>
                    <td><?php echo htmlspecialchars($row['platform']); ?></td>
                    <td><?php echo htmlspecialchars($row['sale_date']); ?></td>
                    <td><?php echo number_format($row['net_sales'], 2); ?></td>
                    <td><?php echo htmlspecialchars($row['payment_channel']); ?></td>
                    <td><?php echo htmlspecialchars($row['buyer_name']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
    
    <?php sqlsrv_close($conn); ?>
</body>
</html>