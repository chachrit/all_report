<?php
// เปิดการแสดงข้อผิดพลาดชั่วคราวเพื่อ Debug (ปิดเมื่อใช้งานจริง)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// 1. เชื่อมต่อฐานข้อมูล
try {
    require_once __DIR__ . '/database.php';
    
    if (!$conn) {
        throw new Exception("ไม่สามารถเชื่อมต่อฐานข้อมูลได้: " . print_r(sqlsrv_errors(), true));
    }
} catch (Exception $e) {
    die("<h1>Database Connection Error</h1><pre>" . $e->getMessage() . "</pre>");
}

$message = '';
$messageType = '';
$stats = ['total' => 0, 'success' => 0, 'skipped' => 0, 'error' => 0];
$errors = [];

// --- Helper Functions ---

function convertToUtf8($content) {
    // ลบ BOM
    if (substr($content, 0, 3) === "\xEF\xBB\xBF") {
        $content = substr($content, 3);
    }
    
    // ตรวจสอบ Encoding (ใช้ Windows-874 แทน TIS-620 สำหรับ PHP 8+)
    $encodings = ['UTF-8', 'Windows-874', 'ISO-8859-1'];
    $encoding = mb_detect_encoding($content, $encodings, true);
    
    if ($encoding && $encoding !== 'UTF-8') {
        return mb_convert_encoding($content, 'UTF-8', $encoding);
    }
    return $content;
}

function convertDate($dateStr) {
    if (empty($dateStr)) return null;
    $dateStr = trim($dateStr);
    // รูปแบบใน CSV คือ m/d/Y (เช่น 6/5/2026)
    $date = DateTime::createFromFormat('m/d/Y', $dateStr);
    if ($date) return $date->format('Y-m-d');
    
    // ลองรูปแบบอื่นถ้าไม่ตรง
    return date('Y-m-d', strtotime($dateStr));
}

function convertDateTime($dateTimeStr) {
    if (empty($dateTimeStr)) return null;
    $dateTimeStr = trim($dateTimeStr);
    // รูปแบบใน CSV คือ m/d/y g:i A (เช่น 6/5/26 2:32 PM)
    $formats = ['m/d/y g:i A', 'n/j/y g:i A', 'm/d/Y g:i A'];
    
    foreach ($formats as $format) {
        $date = DateTime::createFromFormat($format, $dateTimeStr);
        if ($date !== false) {
            return $date->format('Y-m-d H:i:s');
        }
    }
    return date('Y-m-d H:i:s', strtotime($dateTimeStr));
}

function cleanNumber($val) {
    if (empty($val) || strtoupper(trim($val)) === 'NULL') return 0;
    $val = str_replace(',', '', trim($val));
    return is_numeric($val) ? floatval($val) : 0;
}

function cleanString($val) {
    if (empty($val) || strtoupper(trim($val)) === 'NULL') return null;
    return trim($val);
}

// --- Process Upload ---

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    $file = $_FILES['csv_file'];
    $batchId = 'JST_' . date('Ymd_His');
    
    if ($file['error'] === UPLOAD_ERR_OK) {
        $tmpName = $file['tmp_name'];
        
        // อ่านและแปลง Encoding
        $content = file_get_contents($tmpName);
        $content = convertToUtf8($content);
        file_put_contents($tmpName, $content);
        
        $handle = fopen($tmpName, 'r');
        
        if ($handle !== false) {
            // อ่าน Header
            $header = fgetcsv($handle);
            
            if ($header === false) {
                $message = "ไฟล์ว่างเปล่าหรืออ่านไม่ได้";
                $messageType = 'error';
            } else {
                // สร้าง Map ของ Column
                $columnMap = [];
                foreach ($header as $index => $colName) {
                    $columnMap[trim($colName)] = $index;
                }
                
                // ตรวจสอบว่ามี Column จำเป็นหรือไม่
                $requiredCols = ['orderId', 'sale_date', 'net_sales'];
                foreach ($requiredCols as $col) {
                    if (!isset($columnMap[$col])) {
                        $message = "ไม่พบ Column '$col' ในไฟล์ CSV";
                        $messageType = 'error';
                        break;
                    }
                }
                
                if (empty($message)) {
                    sqlsrv_begin_transaction($conn);
                    
                    try {
                        $lineNum = 1;
                        while (($data = fgetcsv($handle)) !== false) {
                            $lineNum++;
                            $stats['total']++;
                            
                            // ข้ามแถวว่าง
                            if (empty($data[0])) continue;
                            
                            $orderId = trim($data[$columnMap['orderId']] ?? '');
                            if (empty($orderId)) {
                                $stats['error']++;
                                continue;
                            }
                            
                            // ตรวจสอบ Duplicate
                            $checkSql = "SELECT COUNT(*) as cnt FROM jst_sale_detail WHERE orderId = ?";
                            $checkStmt = sqlsrv_query($conn, $checkSql, [$orderId]);
                            $checkRow = sqlsrv_fetch_array($checkStmt, SQLSRV_FETCH_ASSOC);
                            sqlsrv_free_stmt($checkStmt);
                            
                            if ($checkRow['cnt'] > 0) {
                                $stats['skipped']++;
                                continue;
                            }
                            
                            // เตรียมข้อมูล
                            $params = [
                                $orderId,
                                cleanString($data[$columnMap['orderNumber']] ?? ''),
                                cleanString($data[$columnMap['platformOrderId']] ?? ''),
                                convertDate($data[$columnMap['sale_date']] ?? ''),
                                convertDateTime($data[$columnMap['order_datetime']] ?? ''),
                                cleanString($data[$columnMap['status']] ?? ''),
                                cleanString($data[$columnMap['statusDisplay']] ?? ''),
                                cleanString($data[$columnMap['platform']] ?? ''),
                                cleanNumber($data[$columnMap['subtotal']] ?? 0),
                                cleanNumber($data[$columnMap['net_sales']] ?? 0),
                                cleanNumber($data[$columnMap['shop_discount']] ?? 0),
                                cleanNumber($data[$columnMap['total_discount']] ?? 0),
                                cleanNumber($data[$columnMap['freight']] ?? 0),
                                cleanString($data[$columnMap['payment_channel']] ?? ''),
                                cleanString($data[$columnMap['buyer_name']] ?? ''),
                                $batchId
                            ];
                            
                            $sql = "INSERT INTO jst_sale_detail 
                                    (orderId, orderNumber, platformOrderId, sale_date, order_datetime, 
                                     status, statusDisplay, platform, subtotal, net_sales, 
                                     shop_discount, total_discount, freight, payment_channel, buyer_name, import_batch)
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                                    
                            $stmt = sqlsrv_query($conn, $sql, $params);
                            
                            if ($stmt === false) {
                                $stats['error']++;
                                $errs = sqlsrv_errors();
                                $errors[] = "Line $lineNum: " . ($errs[0]['message'] ?? 'Unknown Error');
                            } else {
                                $stats['success']++;
                            }
                        }
                        
                        if ($stats['error'] == 0) {
                            sqlsrv_commit($conn);
                            $message = "✅ อัปโหลดสำเร็จ! Batch: $batchId (รวม {$stats['success']} รายการ)";
                            $messageType = 'success';
                        } else {
                            sqlsrv_rollback($conn);
                            $message = "❌ พบข้อผิดพลาด {$stats['error']} รายการ ยกเลิกการบันทึก";
                            $messageType = 'error';
                        }
                        
                    } catch (Exception $e) {
                        sqlsrv_rollback($conn);
                        $message = "❌ System Error: " . $e->getMessage();
                        $messageType = 'error';
                    }
                }
            }
            fclose($handle);
        }
    } else {
        $message = "❌ ไฟล์อัปโหลดไม่สมบูรณ์ (Error Code: " . $file['error'] . ")";
        $messageType = 'error';
    }
}

// ดึงข้อมูลสรุป
$summaryData = [];
$sumSql = "SELECT TOP 5 platform, COUNT(*) as total, SUM(net_sales) as sales FROM jst_sale_detail GROUP BY platform ORDER BY sales DESC";
$sumStmt = sqlsrv_query($conn, $sumSql);
if ($sumStmt) {
    while ($row = sqlsrv_fetch_array($sumStmt, SQLSRV_FETCH_ASSOC)) {
        $summaryData[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Import JST Sale Detail</title>
    <style>
        body { font-family: sans-serif; background: #f4f6f9; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 10px; }
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 4px; }
        .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; font-weight: bold; }
        input[type="file"] { display: block; width: 100%; padding: 10px; border: 1px dashed #ccc; }
        button { background: #007bff; color: white; border: none; padding: 12px 25px; border-radius: 4px; cursor: pointer; font-size: 16px; }
        button:hover { background: #0056b3; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
        th { background: #f8f9fa; }
        .stats { display: flex; gap: 15px; margin-bottom: 20px; }
        .stat-box { flex: 1; padding: 15px; background: #f8f9fa; border-radius: 4px; text-align: center; }
        .stat-box h3 { margin: 0; font-size: 24px; color: #007bff; }
        .stat-box p { margin: 5px 0 0; color: #666; }
    </style>
</head>
<body>
    <div class="container">
        <h1>📦 Import JST Sale Detail</h1>
        
        <?php if ($message): ?>
            <div class="alert alert-<?php echo $messageType; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($stats['total'] > 0): ?>
        <div class="stats">
            <div class="stat-box"><h3><?php echo $stats['total']; ?></h3><p>ทั้งหมด</p></div>
            <div class="stat-box"><h3 style="color:green"><?php echo $stats['success']; ?></h3><p>สำเร็จ</p></div>
            <div class="stat-box"><h3 style="color:orange"><?php echo $stats['skipped']; ?></h3><p>ข้าม (ซ้ำ)</p></div>
            <div class="stat-box"><h3 style="color:red"><?php echo $stats['error']; ?></h3><p>ผิดพลาด</p></div>
        </div>
        <?php endif; ?>
        
        <div class="form-group">
            <form method="POST" enctype="multipart/form-data">
                <label>เลือกไฟล์ JST_sale_detail.csv:</label>
                <input type="file" name="csv_file" accept=".csv" required>
                <br>
                <button type="submit">🚀 เริ่มอัปโหลด</button>
            </form>
        </div>
        
        <?php if (!empty($summaryData)): ?>
        <h3>📊 สรุปยอดขายล่าสุด (Top Platforms)</h3>
        <table>
            <thead>
                <tr>
                    <th>Platform</th>
                    <th>จำนวนออเดอร์</th>
                    <th>ยอดรวมสุทธิ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($summaryData as $row): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['platform']); ?></td>
                    <td><?php echo number_format($row['total']); ?></td>
                    <td><?php echo number_format($row['sales'], 2); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</body>
</html>