<?php
// import_ada.php - อัปโหลด Pos-sale-detail.csv
// หมายเหตุ: ไฟล์ Pos-sale-detail.csv ยังว่างเปล่า โค้ดนี้เตรียมโครงสร้างไว้
// เมื่อมีไฟล์จริงให้ปรับ column mapping ตาม header ของไฟล์
// import_ada.php - อัปโหลด Pos-sale-detail.csv
session_start();

// ✅ แก้ path โดยใช้ __DIR__ เพื่ออ้างอิงจากโฟลเดอร์ปัจจุบัน
require_once __DIR__ . '/../database.php';

$message = '';
$messageType = '';
$stats = ['total' => 0, 'success' => 0, 'skipped' => 0, 'error' => 0];
$errors = [];

function convertDate($dateStr) {
    if (empty($dateStr)) return null;
    $dateStr = trim($dateStr);
    try {
        $date = DateTime::createFromFormat('m/d/Y', $dateStr);
        if ($date) return $date->format('Y-m-d');
        return date('Y-m-d', strtotime($dateStr));
    } catch (Exception $e) {
        return null;
    }
}

function convertDateTime($dateTimeStr) {
    if (empty($dateTimeStr)) return null;
    try {
        return date('Y-m-d H:i:s', strtotime(trim($dateTimeStr)));
    } catch (Exception $e) {
        return null;
    }
}

function convertNumber($numStr) {
    if (empty($numStr) || strtoupper(trim($numStr)) === 'NULL') return 0;
    $numStr = str_replace(',', '', trim($numStr));
    return is_numeric($numStr) ? floatval($numStr) : 0;
}

function convertNull($val) {
    if (empty($val) || strtoupper(trim($val)) === 'NULL') return null;
    return trim($val);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    $file = $_FILES['csv_file'];
    $batchId = 'POS_' . date('Ymd_His');
    
    if ($file['error'] === UPLOAD_ERR_OK) {
        $tmpName = $file['tmp_name'];
        
        $content = file_get_contents($tmpName);
        $encoding = mb_detect_encoding($content, ['UTF-8', 'TIS-620', 'ISO-8859-1', 'ASCII'], true);
        if ($encoding && $encoding !== 'UTF-8') {
            $content = mb_convert_encoding($content, 'UTF-8', $encoding);
            file_put_contents($tmpName, $content);
        }
        
        $handle = fopen($tmpName, 'r');
        
        if ($handle !== false) {
            $header = fgetcsv($handle);
            
            if ($header === false) {
                $message = "ไฟล์ว่างเปล่า";
                $messageType = 'error';
            } else {
                $columnMap = [];
                foreach ($header as $index => $colName) {
                    $columnMap[trim($colName)] = $index;
                }
                
                // แสดง header ให้ดูเพื่อ debug
                $detectedColumns = array_keys($columnMap);
                
                $sql = "INSERT INTO pos_sale_detail 
                        (order_id, order_date, order_time, customer_name, 
                         subtotal, discount, net_amount, payment_method, status, import_batch)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                
                sqlsrv_begin_transaction($conn);
                
                try {
                    $lineNumber = 1;
                    while (($data = fgetcsv($handle)) !== false) {
                        $lineNumber++;
                        $stats['total']++;
                        
                        if (empty($data[0])) continue;
                        
                        // ปรับ column names ตามไฟล์จริง
                        $orderId = trim($data[0] ?? '');
                        $orderDate = convertDate($data[1] ?? '');
                        $orderTime = convertDateTime($data[2] ?? '');
                        $customerName = convertNull($data[3] ?? '');
                        $subtotal = convertNumber($data[4] ?? 0);
                        $discount = convertNumber($data[5] ?? 0);
                        $netAmount = convertNumber($data[6] ?? 0);
                        $paymentMethod = convertNull($data[7] ?? '');
                        $status = convertNull($data[8] ?? '');
                        
                        $params = [
                            $orderId, $orderDate, $orderTime, $customerName,
                            $subtotal, $discount, $netAmount, $paymentMethod, $status, $batchId
                        ];
                        
                        $stmt = sqlsrv_query($conn, $sql, $params);
                        if ($stmt === false) {
                            $stats['error']++;
                            $errs = sqlsrv_errors();
                            $errors[] = "บรรทัด {$lineNumber}: " . ($errs[0]['message'] ?? 'Unknown error');
                        } else {
                            $stats['success']++;
                        }
                    }
                    
                    if ($stats['error'] === 0) {
                        sqlsrv_commit($conn);
                        $message = "✅ อัปโหลดสำเร็จ! Batch: {$batchId}";
                        $messageType = 'success';
                    } else {
                        sqlsrv_rollback($conn);
                        $message = "❌ มีข้อผิดพลาด {$stats['error']} รายการ";
                        $messageType = 'error';
                    }
                    
                } catch (Exception $e) {
                    sqlsrv_rollback($conn);
                    $message = "❌ Exception: " . $e->getMessage();
                    $messageType = 'error';
                }
            }
            
            fclose($handle);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Import POS Sale Detail</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container { max-width: 1200px; margin: 0 auto; }
        .header {
            background: white;
            padding: 25px 30px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .header h1 { color: #333; font-size: 28px; margin-bottom: 5px; }
        .header p { color: #666; font-size: 14px; }
        .card {
            background: white;
            padding: 25px 30px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .card h2 {
            color: #333;
            font-size: 20px;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f5576c;
        }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; font-weight: 600; color: #555; }
        input[type="file"] {
            width: 100%;
            padding: 12px;
            border: 2px dashed #f5576c;
            border-radius: 8px;
            background: #fff5f7;
            cursor: pointer;
        }
        button {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            padding: 14px 40px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
        }
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .alert-success { background: #d4edda; color: #155724; border-left: 4px solid #28a745; }
        .alert-error { background: #f8d7da; color: #721c24; border-left: 4px solid #dc3545; }
        .nav-links { display: flex; gap: 10px; margin-bottom: 20px; }
        .nav-links a {
            padding: 10px 20px;
            background: white;
            color: #f5576c;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
        }
        .nav-links a.active { background: #f5576c; color: white; }
        .info-box {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .columns-list {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            font-family: monospace;
            font-size: 13px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🏪 Import POS Sale Detail</h1>
            <p>อัปโหลดไฟล์ Pos-sale-detail.csv ลงฐานข้อมูล SQL Server</p>
        </div>
        
        <div class="nav-links">
            <a href="import.jst.php">📦 JST Sale</a>
            <a href="import_ada.php" class="active">🏪 POS Sale</a>
        </div>
        
        <?php if ($message): ?>
            <div class="alert alert-<?php echo $messageType; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        
        <div class="info-box">
            <strong>⚠️ หมายเหตุ:</strong> ไฟล์ Pos-sale-detail.csv ยังเป็นไฟล์ว่าง 
            เมื่อมีไฟล์จริง ให้ปรับ column mapping ในโค้ดตาม header ของไฟล์
        </div>
        
        <div class="card">
            <h2>📤 อัปโหลดไฟล์ CSV</h2>
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="csv_file">เลือกไฟล์ Pos-sale-detail.csv:</label>
                    <input type="file" name="csv_file" id="csv_file" accept=".csv" required>
                </div>
                <button type="submit">🚀 เริ่มอัปโหลด</button>
            </form>
        </div>
        
        <?php if (!empty($errors)): ?>
        <div class="card">
            <h2>❌ ข้อผิดพลาด</h2>
            <div class="columns-list">
                <?php foreach (array_slice($errors, 0, 20) as $err): ?>
                    <div>• <?php echo htmlspecialchars($err); ?></div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>